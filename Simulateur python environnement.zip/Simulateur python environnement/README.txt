installation et execution du simulateur python:

pip install -r requirements.txt
python main.py
